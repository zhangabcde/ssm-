package com.HHU.service;

import com.HHU.entity.Accout;
import org.springframework.stereotype.Service;

import java.util.List;

public interface AccoutService {
    public void save(Accout accout);
    public List<Accout> findAll();
    public void deleteById(Integer id);
    public void updateById(Integer id,String name);
}
