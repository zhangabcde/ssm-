package com.HHU.dao;

import com.HHU.entity.Accout;
import org.apache.ibatis.annotations.Param;
import java.util.List;

public interface AccoutMapper {

    public void save(Accout accout);
    public List<Accout> findAll();
    public void deleteById(Integer id);
    public void updateById(@Param("id") Integer id, @Param("name") String name);



}
