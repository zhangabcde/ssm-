package com.HHU.service.impl;

import com.HHU.dao.AccoutMapper;
import com.HHU.entity.Accout;
import com.HHU.service.AccoutService;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
@Service
public class AccoutServiceImpl implements AccoutService {

    @Autowired
    private AccoutMapper accoutMapper;
    /**
     * 当AccoutMapper加入spring容器中时，不能直接注入，要使用代码实现。
     * @param accout
     */
    @Override
    public void save(Accout accout) {
        accoutMapper.save(accout);
    }

    @Override
    public List<Accout> findAll() {
        return accoutMapper.findAll();
    }

    @Override
    public void deleteById(Integer id) {
        accoutMapper.deleteById(id);
    }

    @Override
    public void updateById(Integer id, String name) {
        accoutMapper.updateById(id,name);
    }
}
