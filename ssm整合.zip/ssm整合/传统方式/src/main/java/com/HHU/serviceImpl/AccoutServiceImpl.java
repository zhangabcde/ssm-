package com.HHU.serviceImpl;

import com.HHU.dao.AccoutMapper;
import com.HHU.entity.Accout;
import com.HHU.service.AccoutService;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
@Service
public class AccoutServiceImpl implements AccoutService {

    /**
     * 当AccoutMapper加入spring容器中时，不能直接注入，要使用代码实现。
     * @param accout
     */
    @Override
    public void save(Accout accout) {

        try {
            InputStream resource = Resources.getResourceAsStream("mybatis-config.xml");
            SqlSessionFactory SessionFactory = new SqlSessionFactoryBuilder().build(resource);
            SqlSession sqlSession = SessionFactory.openSession();
            AccoutMapper accoutMapper = sqlSession.getMapper(AccoutMapper.class);
//            最关键的对象调用
            accoutMapper.save(accout);
            sqlSession.commit();
            sqlSession.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Accout> findAll() {

        try {
            InputStream resource = Resources.getResourceAsStream("mybatis-config.xml");
            SqlSessionFactory SessionFactory = new SqlSessionFactoryBuilder().build(resource);
            SqlSession sqlSession = SessionFactory.openSession();
            AccoutMapper accoutMapper = sqlSession.getMapper(AccoutMapper.class);
//            最关键的对象调用
            List<Accout> accoutList = accoutMapper.findAll();
            sqlSession.commit();
            sqlSession.close();
            return accoutList;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

}
