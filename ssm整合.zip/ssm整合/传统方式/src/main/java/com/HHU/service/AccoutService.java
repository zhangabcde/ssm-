package com.HHU.service;

import com.HHU.entity.Accout;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public interface AccoutService {
    public void save(Accout accout);
    public List<Accout> findAll();
}
