package com.HHU.dao;

import com.HHU.entity.Accout;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface AccoutMapper {

    public void save(Accout accout);
    public List<Accout> findAll();
}
