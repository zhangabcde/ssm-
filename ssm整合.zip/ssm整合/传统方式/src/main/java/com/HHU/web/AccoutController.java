package com.HHU.web;

import com.HHU.entity.Accout;
import com.HHU.service.AccoutService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;
@Controller
@RequestMapping("AccoutController")
public class AccoutController {
    @Autowired
    private AccoutService accoutService;

    @RequestMapping(value = "/save",produces = "text/html;charset=UTF-8" )
    @ResponseBody
    public String save(Accout accout){
        accoutService.save(accout);
        System.out.println(accout);
        return "保存成功";
    }

    @RequestMapping(value = "/findAll",produces = "text/html;charset=UTF-8" )
    @ResponseBody
    public ModelAndView findAll(){
        ModelAndView modelAndView = new ModelAndView();
        List<Accout> accoutList = accoutService.findAll();
        modelAndView.addObject("accoutList",accoutList);
        modelAndView.setViewName("findAll");
        System.out.println(accoutList);
        return modelAndView;
    }

}
